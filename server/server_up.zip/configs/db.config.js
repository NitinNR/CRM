// module.exports = {
//     HOST: "localhost",
//     USER: "ketan",
//     PASSWORD: "ketan123",
//     DB: "lifeelbot_crm",
//   };

  // nitin changes

// module.exports = {
//   HOST: "localhost",
//   USER: "root",
//   PASSWORD: "mysql@root",
//   DB: "lifeelbot_crm",
//   PORT:3306
// };


module.exports = {
  HOST: "localhost",
  USER: "root",
  PASSWORD: "",
  DB: "lifeelbot_crm",
  PORT:3306
  };